package com.example.memory;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    private GridView gridView;
    private int[] images = {R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4, R.drawable.image5, R.drawable.image6, R.drawable.image7, R.drawable.image8, R.drawable.image9, R.drawable.image10, R.drawable.image11, R.drawable.image12};
    private int[] imagePositions;
    private int firstImageIndex = -1;
    private int secondImageIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setam adapterul pentru gridView
        gridView = findViewById(R.id.gridView);
        gridView.setAdapter(new ImageAdapter(this, images));

        // Initializam imagePositions cu valori aleatoare pentru fiecare imagine
        imagePositions = new int[images.length * 2];
        ArrayList<Integer> positions = new ArrayList<>();
        for (int i = 0; i < images.length; i++) {
            positions.add(i);
            positions.add(i);
        }
        Collections.shuffle(positions);
        for (int i = 0; i < positions.size(); i++) {
            imagePositions[i] = positions.get(i);
        }

        // Setam un listener pentru gridView pentru a trata evenimentul de click pe fiecare imagine
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                ImageView imageView = view.findViewById(R.id.gridView);
                int imageIndex = imagePositions[position];

                // Daca aceasta este prima imagine apasata
                if (firstImageIndex == -1) {
                    firstImageIndex = imageIndex;
                    imageView.setImageResource(images[firstImageIndex]);
                }
                // Daca aceasta este a doua imagine apasata
                else if (secondImageIndex == -1) {
                    secondImageIndex = imageIndex;
                    imageView.setImageResource(images[secondImageIndex]);

                    // Verificam daca imaginile selectate sunt la fel
                    if (firstImageIndex == secondImageIndex) {
                        Toast.makeText(MainActivity.this, "Felicitari! Ai gasit o pereche!", Toast.LENGTH_SHORT).show();
                    } else {
                        // Daca imaginile nu sunt la fel, asteptam 1 secunda si apoi resetam imaginile la imaginea initiala
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                ImageView firstImageView = gridView.getChildAt(positions.indexOf(firstImageIndex)).findViewById(R.id.gridView);
                                ImageView secondImageView = gridView.getChildAt(positions.indexOf(secondImageIndex)).findViewById(R.id.gridView);
                                firstImageView.setImageResource(R.drawable.cover);
                                secondImageView.setImageResource(R.drawable.cover);
                                firstImageIndex = -1;
                                secondImageIndex = -1;
                            }
                        }, 1000);
                    }
                }
            }
        });
    }
}
